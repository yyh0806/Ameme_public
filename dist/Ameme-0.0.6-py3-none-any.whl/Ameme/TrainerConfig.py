
class TrainerConfig:

    num_workers = 4
    batch_size = 16
    n_epochs = 25
    lr = 0.001
